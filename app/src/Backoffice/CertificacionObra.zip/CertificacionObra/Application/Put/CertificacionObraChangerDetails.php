<?php

declare(strict_types=1);

namespace App\Backoffice\CertificacionObra\Application\Put;

use App\Backoffice\CertificacionObra\Application\Get\Single\CertificacionObraFinder;
use App\Backoffice\CertificacionObra\Domain\CertificacionObra;
use App\Backoffice\CertificacionObra\Domain\JobDesignationNameIsAvailableSpecification;
use App\Backoffice\CertificacionObra\Domain\CertificacionObraRepository;
use App\Backoffice\CertificacionObra\Domain\ValueObject\JobDesignationBiography;
use App\Backoffice\CertificacionObra\Domain\ValueObject\JobDesignationName;

final class CertificacionObraChangerDetails
{
	private CertificacionObraRepository                   $repository;
	private CertificacionObraFinder                       $finder;

	public function __construct(CertificacionObraRepository $repository
	)
	{
		$this->repository = $repository;
		$this->finder     = new CertificacionObraFinder($repository);
	}

	public function __invoke(
		$id,
		$nombres,
		$apellido,
		$numeroObra,
		$etapa,
		$permiteModificarComputo,
		$certificacionManual,
		$insGrabaCert,
		$programa,
		$departamento,
		$localidad,
		$codigoPostal,
		$numeroLicitacion,
		$tipoLicitacion,
		$fechaLicitacion,
		$fechaInicioObra,
		$plazo,
		$contratista,
		$anticipoFinancieroNacion,
		$anticipoFinancieroProvincia,
		$aporteNacion,
		$aporteProvincia,
		$ampliacionMontoNacion,
		$ampliacionMontoProvincia,
		$porcentajeEntregaNacion,
		$porcentajeEntregaProvincia,
		$coeficienteActivo,
		$porcentajeReparo,
		$bapin,
		$montoContratado,
		$presupuestoOficial,
		$costoObra
	)
	{
		$certificacionObra = $this->finder->__invoke($id);

		$certificacionObra->setNombres($nombres);
		$certificacionObra->setApellido($apellido);
		$certificacionObra->setnumeroObra($numeroObra);
		$certificacionObra->setEtapa($etapa);
		$certificacionObra->setPermiteModificarComputo($permiteModificarComputo);
		$certificacionObra->setCertificacionManual($certificacionManual);
		$certificacionObra->setInsGrabaCert($insGrabaCert);
		$certificacionObra->setPrograma($programa);
		$certificacionObra->setDepartamento($departamento);
		$certificacionObra->setLocalidad($localidad);
		$certificacionObra->setCodigoPostal($codigoPostal);
		$certificacionObra->setNumeroLicitacion($numeroLicitacion);
		$certificacionObra->setTipoLicitacion($tipoLicitacion);
		$certificacionObra->setFechaLicitacion($fechaLicitacion);
		$certificacionObra->setFechaInicioObra($fechaInicioObra);
		$certificacionObra->setPlazo($plazo);
		$certificacionObra->setContratista($contratista);
		$certificacionObra->setanticipoFinancieroNacion($anticipoFinancieroNacion);
		$certificacionObra->setanticipoFinancieroProvincia($anticipoFinancieroProvincia);
		$certificacionObra->setAporteNacion($aporteNacion);
		$certificacionObra->setAporteProvincia($aporteProvincia);
		$certificacionObra->setAmpliacionMontoNacion($ampliacionMontoNacion);
		$certificacionObra->setAmpliacionMontoProvincia($ampliacionMontoProvincia);
		$certificacionObra->setporcentajeEntregaNacion($porcentajeEntregaNacion);
		$certificacionObra->setporcentajeEntregaProvincia($porcentajeEntregaProvincia);
		$certificacionObra->setCoeficienteActivo($coeficienteActivo);
		$certificacionObra->setPorcentajeReparo($porcentajeReparo);
		$certificacionObra->setBapin($bapin);
		$certificacionObra->setMontoContratado($montoContratado);
		$certificacionObra->setPresupuestoOficial($presupuestoOficial);
		$certificacionObra->setCostoObra($costoObra);
		$certificacionObra->setCreateAt($createAt);
		$this->repository->save($certificacionObra);

		$this->repository->save($certificacionObra);
	}
}